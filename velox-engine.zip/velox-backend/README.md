# Velox Engine

Real-time swing screener backend. Powers the Velox frontend on Vercel.

## Stack
- **FastAPI** — API framework
- **yfinance** — market data
- **pandas + pandas-ta** — indicators
- **Railway** — deployment

## Local setup

```bash
cd velox-backend
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

Open http://localhost:8000/docs for the interactive API explorer.

## Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/health` | Health check |
| GET | `/api/regime` | Live market regime (SPY + VIX) |
| GET | `/api/sectors` | Sector RS rankings |
| GET | `/api/ticker/{symbol}` | Full analysis for one stock |
| POST | `/api/screen/start` | Start async screen job |
| GET | `/api/screen/status/{job_id}` | Poll screen progress |
| GET | `/api/screen/quick` | Fast sync screen (top 200 names) |
| GET | `/api/momentum?period=1M` | Momentum leaders by period |

## Deploy to Railway

1. Push this folder to a GitHub repo called `velox-engine`
2. Go to railway.app → New Project → Deploy from GitHub
3. Select `velox-engine`
4. Railway auto-detects Python + installs deps
5. Your API goes live at `https://velox-engine-production.up.railway.app`

## Connect to Velox frontend

In your Velox frontend, set:
```
VITE_API_URL=https://your-railway-url.up.railway.app
```
