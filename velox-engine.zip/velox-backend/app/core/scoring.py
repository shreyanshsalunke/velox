"""
scoring.py
The heart of Velox. Pulls OHLCV data, calculates all indicators,
scores every stock across 5 axes, and returns ranked results.
"""

import yfinance as yf
import pandas as pd
import numpy as np
import logging
from datetime import datetime, timedelta
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Optional

logger = logging.getLogger(__name__)

# ── Constants ────────────────────────────────────────────────────────────────
BATCH_SIZE      = 50       # tickers per yfinance batch download
MAX_WORKERS     = 8        # parallel threads
LOOKBACK_DAYS   = 365      # 1 year of data
MIN_PRICE       = 5.0
MIN_AVG_VOL     = 100_000
MIN_MCAP        = 300_000_000   # $300M
RSI_PERIOD      = 14
MA_PERIODS      = [20, 50, 200]


# ── Indicator helpers ────────────────────────────────────────────────────────

def calc_rsi(closes: pd.Series, period: int = RSI_PERIOD) -> float:
    """Wilder RSI."""
    delta = closes.diff()
    gain  = delta.clip(lower=0)
    loss  = (-delta).clip(lower=0)
    avg_gain = gain.ewm(alpha=1/period, adjust=False).mean()
    avg_loss = loss.ewm(alpha=1/period, adjust=False).mean()
    rs = avg_gain / avg_loss.replace(0, np.nan)
    rsi = 100 - (100 / (1 + rs))
    return round(float(rsi.iloc[-1]), 1)


def calc_atr(high: pd.Series, low: pd.Series, close: pd.Series, period: int = 14) -> float:
    """Average True Range."""
    tr = pd.concat([
        high - low,
        (high - close.shift()).abs(),
        (low  - close.shift()).abs(),
    ], axis=1).max(axis=1)
    return float(tr.ewm(span=period, adjust=False).mean().iloc[-1])


def calc_rs(stock_closes: pd.Series, spy_closes: pd.Series, period: int = 63) -> float:
    """Relative strength vs SPY over ~3 months (63 trading days)."""
    n = min(period, len(stock_closes) - 1, len(spy_closes) - 1)
    if n < 5:
        return 0.0
    stock_ret = (stock_closes.iloc[-1] / stock_closes.iloc[-n] - 1) * 100
    spy_ret   = (spy_closes.iloc[-1]   / spy_closes.iloc[-n]   - 1) * 100
    return round(stock_ret - spy_ret, 1)


def calc_rvol(volume: pd.Series, lookback: int = 20) -> float:
    """Relative volume: today vs 20-day average."""
    if len(volume) < lookback + 1:
        return 1.0
    avg = volume.iloc[-(lookback+1):-1].mean()
    if avg == 0:
        return 1.0
    return round(float(volume.iloc[-1] / avg), 2)


def pct_from_ma(close: float, ma_series: pd.Series) -> float:
    """% distance from a moving average."""
    ma_val = float(ma_series.iloc[-1])
    if ma_val == 0:
        return 0.0
    return round((close / ma_val - 1) * 100, 1)


def is_near_52wk_high(closes: pd.Series, threshold: float = 0.05) -> bool:
    """True if price is within threshold% of 52-week high."""
    high_52 = closes.tail(252).max()
    return float(closes.iloc[-1]) >= high_52 * (1 - threshold)


def detect_setup(close: float, ma20: float, ma50: float,
                 closes: pd.Series, rvol: float) -> str:
    """Classify the price structure setup."""
    price_52wk_high = closes.tail(252).max()
    near_high = close >= price_52wk_high * 0.95

    # Breakout: near 52wk high + volume expansion
    if near_high and rvol >= 1.5:
        return "Breakout"

    # Basing: tight range, above MAs
    recent_range = (closes.tail(30).max() - closes.tail(30).min()) / closes.tail(30).mean()
    if close > ma50 and recent_range < 0.08:
        return "Basing"

    # Pullback: above 50MA but pulled back from recent high
    recent_high = closes.tail(20).max()
    if close > ma50 and close < recent_high * 0.95:
        return "Pullback"

    # Weak
    if close < ma50:
        return "Weak"

    return "Basing"


# ── Scoring ───────────────────────────────────────────────────────────────────

def score_trend(close: float, ma20: float, ma50: float, ma200: float) -> int:
    """Score 0-100: price above MAs in correct order."""
    score = 0
    if close > ma20:  score += 25
    if close > ma50:  score += 25
    if close > ma200: score += 25
    if ma20 > ma50 > ma200: score += 25
    return score


def score_momentum(rsi: float, rs3m: float) -> int:
    """Score 0-100: RSI position + relative strength."""
    score = 0
    # RSI component (50 pts)
    if rsi > 70:   score += 40
    elif rsi > 60: score += 50
    elif rsi > 50: score += 35
    elif rsi > 40: score += 15
    # RS component (50 pts)
    if rs3m > 30:   score += 50
    elif rs3m > 15: score += 40
    elif rs3m > 5:  score += 25
    elif rs3m > 0:  score += 10
    return min(score, 100)


def score_volume(rvol: float, avg_vol: float) -> int:
    """Score 0-100: relative volume + liquidity."""
    score = 0
    # Relative volume (60 pts)
    if rvol >= 2.0:   score += 60
    elif rvol >= 1.5: score += 50
    elif rvol >= 1.2: score += 40
    elif rvol >= 1.0: score += 30
    elif rvol >= 0.7: score += 15
    # Liquidity (40 pts)
    if avg_vol >= 5_000_000:   score += 40
    elif avg_vol >= 1_000_000: score += 35
    elif avg_vol >= 500_000:   score += 25
    elif avg_vol >= 100_000:   score += 15
    return min(score, 100)


def score_sector(sector: str, sector_rs_map: dict) -> int:
    """Score 0-100: sector relative strength rank."""
    rs = sector_rs_map.get(sector, 0)
    if rs > 25:   return 95
    elif rs > 15: return 80
    elif rs > 5:  return 65
    elif rs > 0:  return 50
    elif rs > -5: return 35
    else:         return 20


def score_structure(setup: str, close: float,
                    ma50: float, closes: pd.Series) -> int:
    """Score 0-100: base quality and breakout structure."""
    base = {"Breakout": 90, "Basing": 75, "Pullback": 60, "Weak": 20}.get(setup, 50)
    # Tighten the base score with MA alignment
    if close > ma50:
        base = min(base + 5, 100)
    return base


def composite_score(trend: int, momentum: int, volume: int,
                    sector: int, structure: int) -> int:
    """Weighted composite 0-100."""
    return round(
        trend     * 0.25 +
        momentum  * 0.25 +
        volume    * 0.20 +
        sector    * 0.15 +
        structure * 0.15
    )


# ── Single stock analysis ─────────────────────────────────────────────────────

def analyze_ticker(ticker: str, spy_closes: pd.Series,
                   sector_rs_map: dict) -> Optional[dict]:
    """
    Full analysis for one ticker. Returns dict or None if data insufficient.
    """
    try:
        end   = datetime.today()
        start = end - timedelta(days=LOOKBACK_DAYS + 30)

        tk   = yf.Ticker(ticker)
        hist = tk.history(start=start, end=end, auto_adjust=True)

        if hist.empty or len(hist) < 60:
            return None

        closes = hist["Close"].dropna()
        highs  = hist["High"].dropna()
        lows   = hist["Low"].dropna()
        vols   = hist["Volume"].dropna()

        close    = float(closes.iloc[-1])
        avg_vol  = float(vols.tail(20).mean())

        # Liquidity gates
        if close < MIN_PRICE:       return None
        if avg_vol < MIN_AVG_VOL:   return None

        # MAs
        ma20  = float(closes.tail(20).mean())
        ma50  = float(closes.tail(50).mean()) if len(closes) >= 50  else close
        ma200 = float(closes.tail(200).mean()) if len(closes) >= 200 else close

        # Indicators
        rsi    = calc_rsi(closes)
        rvol   = calc_rvol(vols)
        rs3m   = calc_rs(closes, spy_closes)
        setup  = detect_setup(close, ma20, ma50, closes, rvol)

        # Price changes
        chg_1d  = round((close / float(closes.iloc[-2]) - 1) * 100, 2) if len(closes) >= 2 else 0
        chg_1w  = round((close / float(closes.iloc[-6]) - 1) * 100, 1) if len(closes) >= 6 else 0
        chg_1m  = round((close / float(closes.iloc[-22]) - 1) * 100, 1) if len(closes) >= 22 else 0
        chg_3m  = round((close / float(closes.iloc[-63]) - 1) * 100, 1) if len(closes) >= 63 else 0
        chg_6m  = round((close / float(closes.iloc[-126]) - 1) * 100, 1) if len(closes) >= 126 else 0
        chg_ytd = round((close / float(closes.iloc[-252]) - 1) * 100, 1) if len(closes) >= 252 else chg_6m

        vs20  = round((close / ma20  - 1) * 100, 1)
        vs50  = round((close / ma50  - 1) * 100, 1)
        vs200 = round((close / ma200 - 1) * 100, 1)

        # Sector (fast lookup first, yfinance fallback)
        from app.data.universe import get_sector_for_ticker
        sector = get_sector_for_ticker(ticker)
        if sector == "Unknown":
            try:
                info   = tk.fast_info
                sector = getattr(info, "sector", "Unknown") or "Unknown"
            except Exception:
                pass

        # 52wk high/low
        high_52 = round(float(closes.tail(252).max()), 2)
        low_52  = round(float(closes.tail(252).min()), 2)
        pct_from_high = round((close / high_52 - 1) * 100, 1)

        # Scores
        t_score  = score_trend(close, ma20, ma50, ma200)
        m_score  = score_momentum(rsi, rs3m)
        v_score  = score_volume(rvol, avg_vol)
        se_score = score_sector(sector, sector_rs_map)
        st_score = score_structure(setup, close, ma50, closes)
        c_score  = composite_score(t_score, m_score, v_score, se_score, st_score)

        # Market cap (approximate from fast_info)
        mcap = 0
        try:
            mcap = int(getattr(tk.fast_info, "market_cap", 0) or 0)
        except Exception:
            pass

        if mcap > 0 and mcap < MIN_MCAP:
            return None

        return {
            "ticker":         ticker,
            "sector":         sector,
            "price":          round(close, 2),
            "chg":            chg_1d,
            "chg_1w":         chg_1w,
            "chg_1m":         chg_1m,
            "chg_3m":         chg_3m,
            "chg_6m":         chg_6m,
            "chg_ytd":        chg_ytd,
            "vs20":           vs20,
            "vs50":           vs50,
            "vs200":          vs200,
            "ma20":           round(ma20, 2),
            "ma50":           round(ma50, 2),
            "ma200":          round(ma200, 2),
            "rsi":            rsi,
            "rvol":           rvol,
            "rs3m":           rs3m,
            "avg_vol":        int(avg_vol),
            "mcap":           mcap,
            "high_52":        high_52,
            "low_52":         low_52,
            "pct_from_high":  pct_from_high,
            "setup":          setup,
            "scores": {
                "trend":     t_score,
                "momentum":  m_score,
                "volume":    v_score,
                "sector":    se_score,
                "structure": st_score,
                "composite": c_score,
            },
            "score":          c_score,
        }

    except Exception as e:
        logger.debug(f"{ticker}: {e}")
        return None


# ── Batch runner ──────────────────────────────────────────────────────────────

def get_spy_closes() -> pd.Series:
    """Fetch SPY closes for RS calculation."""
    try:
        spy = yf.download("SPY", period="1y", auto_adjust=True, progress=False)
        return spy["Close"].dropna()
    except Exception:
        return pd.Series(dtype=float)


def get_sector_rs_map(spy_closes: pd.Series) -> dict:
    """
    Compute sector ETF RS vs SPY.
    Returns {sector_name: rs_float}
    """
    etf_map = {
        "Technology":    "XLK",
        "Health Care":   "XLV",
        "Financials":    "XLF",
        "Industrials":   "XLI",
        "Cons. Disc.":   "XLY",
        "Cons. Staples": "XLP",
        "Energy":        "XLE",
        "Materials":     "XLB",
        "Utilities":     "XLU",
        "Real Estate":   "XLRE",
        "Comm. Svcs":    "XLC",
    }
    result = {}
    for sector, etf in etf_map.items():
        try:
            hist = yf.download(etf, period="3mo", auto_adjust=True, progress=False)
            closes = hist["Close"].dropna()
            if len(closes) >= 5:
                etf_ret = (float(closes.iloc[-1]) / float(closes.iloc[0]) - 1) * 100
                spy_ret = (float(spy_closes.iloc[-1]) / float(spy_closes.iloc[-63]) - 1) * 100 if len(spy_closes) >= 63 else 0
                result[sector] = round(etf_ret - spy_ret, 1)
        except Exception:
            result[sector] = 0.0
    return result


def run_screen(
    tickers: list[str],
    filters: dict,
    max_results: int = 50,
    progress_callback=None,
) -> list[dict]:
    """
    Screen a list of tickers against filters, score them, return top results.

    filters keys:
        trend (bool), rsi (bool), rvol (bool), base (bool), eps (bool),
        min_rsi (int), sectors (list[str])
    """
    logger.info(f"Starting screen: {len(tickers)} tickers")

    spy_closes      = get_spy_closes()
    sector_rs_map   = get_sector_rs_map(spy_closes)

    results     = []
    processed   = 0
    total       = len(tickers)

    def process(ticker):
        return analyze_ticker(ticker, spy_closes, sector_rs_map)

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = {executor.submit(process, t): t for t in tickers}
        for future in as_completed(futures):
            processed += 1
            if progress_callback:
                progress_callback(processed, total)
            result = future.result()
            if result is None:
                continue

            # Apply filters
            f = filters
            active_sectors = f.get("sectors", [])

            if active_sectors and result["sector"] not in active_sectors:
                continue
            if f.get("trend") and (result["vs20"] < 0 or result["vs50"] < 0):
                continue
            if f.get("rsi") and result["rsi"] < f.get("min_rsi", 50):
                continue
            if f.get("rvol") and result["rvol"] < 1.0:
                continue
            if f.get("base") and result["setup"] not in ["Breakout", "Basing"]:
                continue

            results.append(result)

    results.sort(key=lambda x: x["score"], reverse=True)
    logger.info(f"Screen complete: {len(results)} setups passed filters")
    return results[:max_results]


def get_market_regime() -> dict:
    """SPY vs 200MA + VIX for regime detection."""
    try:
        spy  = yf.download("SPY", period="1y", auto_adjust=True, progress=False)
        vix  = yf.download("^VIX", period="5d", auto_adjust=True, progress=False)

        spy_close  = round(float(spy["Close"].iloc[-1]), 2)
        spy_200ma  = round(float(spy["Close"].tail(200).mean()), 2)
        vix_close  = round(float(vix["Close"].iloc[-1]), 1)

        above_200  = spy_close > spy_200ma
        vix_ok     = vix_close < 25
        bull       = above_200 and vix_ok

        return {
            "trend":      "BULL" if bull else "BEAR",
            "label":      "Risk-On" if bull else "Risk-Off",
            "spyPrice":   spy_close,
            "spy200ma":   spy_200ma,
            "spyAbove200": above_200,
            "vix":        vix_close,
            "vixOk":      vix_ok,
        }
    except Exception as e:
        logger.error(f"Regime fetch failed: {e}")
        return {
            "trend": "UNKNOWN", "label": "Unknown",
            "spyPrice": 0, "spy200ma": 0,
            "spyAbove200": False, "vix": 0, "vixOk": True,
        }
