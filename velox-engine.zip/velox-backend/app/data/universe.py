"""
universe.py
Fetches the full list of US-listed equities from multiple free sources.
Falls back gracefully if any source is unavailable.
"""

import requests
import pandas as pd
import io
import logging

logger = logging.getLogger(__name__)

# Sector mapping for common tickers (fallback when yfinance sector is missing)
SECTOR_MAP = {
    "Technology": ["AAPL","MSFT","NVDA","META","GOOGL","GOOG","AMZN","TSLA","AMD","INTC",
                   "AVGO","QCOM","TXN","MU","AMAT","LRCX","KLAC","MRVL","CRWD","PANW",
                   "NOW","CRM","ADBE","ORCL","IBM","HPQ","DELL","STX","WDC","CDNS"],
    "Health Care": ["UNH","JNJ","LLY","ABBV","MRK","TMO","ABT","DHR","BMY","AMGN",
                    "GILD","ISRG","VRTX","REGN","ZTS","EW","HCA","CI","CVS","MCK"],
    "Financials":  ["BRK-B","JPM","BAC","WFC","GS","MS","BLK","SCHW","AXP","USB",
                    "PNC","TFC","COF","MMC","ICE","CME","CB","PGR","MET","PRU"],
    "Industrials": ["GE","CAT","UPS","HON","BA","LMT","RTX","DE","MMM","GD",
                    "ITW","EMR","ETN","PH","ROK","CMI","CARR","OTIS","GEV","AXON"],
    "Cons. Disc.":  ["AMZN","TSLA","HD","MCD","NKE","SBUX","TJX","LOW","BKNG","ABNB",
                    "CMG","YUM","ROST","ORLY","AZO","DHI","LEN","NVR","PHM","LULU"],
    "Cons. Staples":["PG","KO","PEP","COST","WMT","PM","MO","CL","KMB","GIS",
                    "HSY","K","SJM","CAG","CPB","HRL","MKC","CLX","CHD","COTY"],
    "Energy":       ["XOM","CVX","COP","EOG","SLB","MPC","PSX","VLO","OXY","PXD",
                    "FANG","DVN","HES","APA","BKR","HAL","NOV","RIG","VIST","CEI"],
    "Materials":    ["LIN","APD","ECL","SHW","FCX","NEM","NUE","VMC","MLM","CF",
                    "MOS","ALB","PPG","EMN","CE","HUN","OLN","CC","WLK","RPM"],
    "Utilities":    ["NEE","DUK","SO","D","AEP","EXC","SRE","XEL","WEC","ES",
                    "ETR","FE","CMS","NI","AES","PPL","EIX","PEG","CNP","LNT"],
    "Real Estate":  ["AMT","PLD","CCI","EQIX","PSA","O","WELL","SPG","DLR","AVB",
                    "EQR","VTR","BXP","ARE","MAA","UDR","CPT","KIM","REG","FRT"],
    "Comm. Svcs":   ["GOOGL","META","NFLX","DIS","CMCSA","VZ","T","TMUS","CHTR","PARA",
                    "WBD","OMC","IPG","TTWO","EA","MTCH","ZM","SNAP","PINS","SPOT"],
}

def get_sp500_tickers() -> list[str]:
    """Scrape S&P 500 tickers from Wikipedia."""
    try:
        url = "https://en.wikipedia.org/wiki/List_of_S%26P_500_companies"
        tables = pd.read_html(url)
        df = tables[0]
        tickers = df["Symbol"].str.replace(".", "-", regex=False).tolist()
        logger.info(f"S&P 500: loaded {len(tickers)} tickers")
        return tickers
    except Exception as e:
        logger.warning(f"S&P 500 fetch failed: {e}")
        return []

def get_nasdaq_tickers() -> list[str]:
    """Fetch NASDAQ-listed tickers from NASDAQ FTP."""
    try:
        url = "https://api.nasdaq.com/api/screener/stocks?tableonly=true&limit=10000&exchange=nasdaq"
        headers = {"User-Agent": "Mozilla/5.0"}
        r = requests.get(url, headers=headers, timeout=15)
        data = r.json()
        rows = data["data"]["table"]["rows"]
        tickers = [row["symbol"].strip() for row in rows if row.get("symbol")]
        tickers = [t for t in tickers if t.isalpha() and len(t) <= 5]
        logger.info(f"NASDAQ: loaded {len(tickers)} tickers")
        return tickers
    except Exception as e:
        logger.warning(f"NASDAQ fetch failed: {e}")
        return []

def get_nyse_tickers() -> list[str]:
    """Fetch NYSE-listed tickers from NASDAQ API."""
    try:
        url = "https://api.nasdaq.com/api/screener/stocks?tableonly=true&limit=10000&exchange=nyse"
        headers = {"User-Agent": "Mozilla/5.0"}
        r = requests.get(url, headers=headers, timeout=15)
        data = r.json()
        rows = data["data"]["table"]["rows"]
        tickers = [row["symbol"].strip() for row in rows if row.get("symbol")]
        tickers = [t for t in tickers if t.replace("-","").isalpha() and len(t) <= 5]
        logger.info(f"NYSE: loaded {len(tickers)} tickers")
        return tickers
    except Exception as e:
        logger.warning(f"NYSE fetch failed: {e}")
        return []

def get_amex_tickers() -> list[str]:
    """Fetch AMEX-listed tickers."""
    try:
        url = "https://api.nasdaq.com/api/screener/stocks?tableonly=true&limit=5000&exchange=amex"
        headers = {"User-Agent": "Mozilla/5.0"}
        r = requests.get(url, headers=headers, timeout=15)
        data = r.json()
        rows = data["data"]["table"]["rows"]
        tickers = [row["symbol"].strip() for row in rows if row.get("symbol")]
        tickers = [t for t in tickers if t.replace("-","").isalpha() and len(t) <= 5]
        logger.info(f"AMEX: loaded {len(tickers)} tickers")
        return tickers
    except Exception as e:
        logger.warning(f"AMEX fetch failed: {e}")
        return []

# Hardcoded fallback — top 200 liquid US names
FALLBACK_TICKERS = [
    "AAPL","MSFT","NVDA","META","GOOGL","AMZN","TSLA","AVGO","LLY","JPM",
    "UNH","XOM","V","MA","JNJ","PG","HD","COST","ABBV","MRK","BAC","NFLX",
    "CRM","CVX","ORCL","AMD","TMO","KO","PEP","ACN","LIN","MCD","CSCO","ABT",
    "GE","CAT","TXN","INTU","QCOM","ISRG","GS","AMAT","HON","BKNG","T","VZ",
    "RTX","NOW","MS","SPGI","BLK","UBER","SYK","AXP","PLD","LOW","DE","AMGN",
    "ADI","LRCX","PANW","VRTX","GILD","KLAC","MRVL","CI","ETN","MU","REGN",
    "CME","ZTS","CB","MMC","WM","CRWD","AXON","GEV","VIST","META","CELH","LULU",
    "WMT","TGT","NKE","SBUX","CMG","YUM","TJX","ROST","ORLY","AZO","DHI","LEN",
    "NEE","DUK","SO","D","AEP","EXC","AMT","PLD","CCI","EQIX","PSA","O",
    "FCX","NEM","NUE","VMC","SHW","LIN","APD","ECL","PPG","ALB","MOS","CF",
    "XOM","CVX","COP","EOG","SLB","MPC","PSX","VLO","OXY","HES","DVN","APA",
    "BRK-B","WFC","USB","PNC","TFC","COF","AIG","MET","PRU","AFL","ALL","TRV",
    "AAPL","MSFT","IBM","HPQ","DELL","STX","WDC","CDNS","SNPS","ANSS","KEYS",
    "UPS","FDX","CSX","NSC","UNP","DAL","UAL","AAL","LUV","ALK","JBLU","SAVE",
    "JNJ","PFE","BMY","AMGN","BIIB","ILMN","IQV","DGX","LH","WAT","A","MTD",
]

def get_full_universe() -> list[str]:
    """
    Build the full US equity universe.
    Tries live sources first, falls back to hardcoded list.
    Returns deduplicated list of tickers.
    """
    tickers = set()

    sp500 = get_sp500_tickers()
    tickers.update(sp500)

    if len(tickers) < 100:
        nasdaq = get_nasdaq_tickers()
        tickers.update(nasdaq)
        nyse = get_nyse_tickers()
        tickers.update(nyse)
        amex = get_amex_tickers()
        tickers.update(amex)

    if len(tickers) < 50:
        logger.warning("All live sources failed — using fallback ticker list")
        tickers.update(FALLBACK_TICKERS)

    # Clean: remove obvious non-equity symbols
    clean = sorted([
        t for t in tickers
        if t and isinstance(t, str)
        and len(t) <= 5
        and t.replace("-","").isalpha()
        and "^" not in t
        and "/" not in t
    ])

    logger.info(f"Universe ready: {len(clean)} tickers")
    return clean


def get_sector_for_ticker(ticker: str) -> str:
    """Quick sector lookup without hitting yfinance."""
    for sector, tickers in SECTOR_MAP.items():
        if ticker in tickers:
            return sector
    return "Unknown"
