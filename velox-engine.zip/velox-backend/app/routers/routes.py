"""
routes.py — All Velox API endpoints
"""

from fastapi import APIRouter, BackgroundTasks, HTTPException, Query
from pydantic import BaseModel
from typing import Optional
import asyncio
import logging
import time

from app.core.scoring import (
    run_screen, get_market_regime, analyze_ticker,
    get_spy_closes, get_sector_rs_map
)
from app.data.universe import get_full_universe

logger = logging.getLogger(__name__)
router = APIRouter()

# ── In-memory job store (simple, no Redis needed) ────────────────────────────
jobs: dict = {}   # job_id -> {status, progress, total, results, error}


# ── Request models ────────────────────────────────────────────────────────────

class ScreenRequest(BaseModel):
    trend:      bool = True
    rsi:        bool = True
    rvol:       bool = True
    base:       bool = False
    eps:        bool = False
    min_rsi:    int  = 50
    sectors:    list[str] = []
    max_results: int = 50
    universe:   str  = "sp500"   # "sp500" | "full"


# ── Endpoints ─────────────────────────────────────────────────────────────────

@router.get("/health")
def health():
    return {"status": "ok", "service": "velox-engine"}


@router.get("/regime")
def regime():
    """Live market regime: SPY vs 200MA + VIX."""
    return get_market_regime()


@router.get("/sectors")
def sectors():
    """Sector RS rankings vs SPY (3-month)."""
    spy = get_spy_closes()
    rs_map = get_sector_rs_map(spy)
    ranked = sorted(
        [{"sector": k, "rs": v} for k, v in rs_map.items()],
        key=lambda x: x["rs"], reverse=True
    )
    return {"sectors": ranked}


@router.get("/ticker/{symbol}")
def ticker_detail(symbol: str):
    """Full analysis for a single ticker."""
    symbol = symbol.upper().strip()
    spy    = get_spy_closes()
    rs_map = get_sector_rs_map(spy)
    result = analyze_ticker(symbol, spy, rs_map)
    if result is None:
        raise HTTPException(status_code=404, detail=f"{symbol}: insufficient data or filtered out")
    return result


@router.post("/screen/start")
def screen_start(req: ScreenRequest, background_tasks: BackgroundTasks):
    """
    Start an async screen job. Returns a job_id immediately.
    Poll /screen/status/{job_id} for progress + results.
    """
    import uuid
    job_id = str(uuid.uuid4())[:8]

    jobs[job_id] = {
        "status":   "running",
        "progress": 0,
        "total":    0,
        "results":  [],
        "error":    None,
        "started":  time.time(),
    }

    def run():
        try:
            if req.universe == "full":
                tickers = get_full_universe()
            else:
                from app.data.universe import get_sp500_tickers, FALLBACK_TICKERS
                tickers = get_sp500_tickers()
                if len(tickers) < 10:
                    tickers = FALLBACK_TICKERS

            jobs[job_id]["total"] = len(tickers)

            def progress_cb(done, total):
                jobs[job_id]["progress"] = done
                jobs[job_id]["total"]    = total

            filters = req.model_dump(exclude={"universe", "max_results"})
            results = run_screen(
                tickers=tickers,
                filters=filters,
                max_results=req.max_results,
                progress_callback=progress_cb,
            )

            jobs[job_id]["results"] = results
            jobs[job_id]["status"]  = "done"

        except Exception as e:
            logger.error(f"Job {job_id} failed: {e}")
            jobs[job_id]["status"] = "error"
            jobs[job_id]["error"]  = str(e)

    background_tasks.add_task(run)
    return {"job_id": job_id, "status": "running"}


@router.get("/screen/status/{job_id}")
def screen_status(job_id: str):
    """Poll screen job progress and results."""
    job = jobs.get(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="Job not found")

    pct = 0
    if job["total"] > 0:
        pct = round(job["progress"] / job["total"] * 100)

    return {
        "job_id":   job_id,
        "status":   job["status"],
        "progress": job["progress"],
        "total":    job["total"],
        "pct":      pct,
        "results":  job["results"] if job["status"] == "done" else [],
        "error":    job["error"],
        "elapsed":  round(time.time() - job["started"], 1),
    }


@router.get("/screen/quick")
def screen_quick(
    min_rsi:  int  = Query(50),
    trend:    bool = Query(True),
    rvol:     bool = Query(True),
    sectors:  str  = Query(""),   # comma-separated
    limit:    int  = Query(20),
):
    """
    Synchronous quick screen against the fallback 200-name universe.
    Returns in ~30-60s. Good for mobile / single-click use.
    """
    from app.data.universe import FALLBACK_TICKERS
    sector_list = [s.strip() for s in sectors.split(",") if s.strip()]
    filters = {
        "trend":   trend,
        "rsi":     True,
        "rvol":    rvol,
        "base":    False,
        "eps":     False,
        "min_rsi": min_rsi,
        "sectors": sector_list,
    }
    results = run_screen(
        tickers=FALLBACK_TICKERS[:200],
        filters=filters,
        max_results=limit,
    )
    return {"count": len(results), "results": results}


@router.get("/momentum")
def momentum(period: str = Query("1M")):
    """
    Top momentum names for a given period.
    Uses the quick universe for speed.
    """
    from app.data.universe import FALLBACK_TICKERS
    spy    = get_spy_closes()
    rs_map = get_sector_rs_map(spy)

    period_field = {
        "1W": "chg_1w", "1M": "chg_1m",
        "3M": "chg_3m", "6M": "chg_6m", "YTD": "chg_ytd",
    }.get(period, "chg_1m")

    results = []
    with __import__("concurrent.futures", fromlist=["ThreadPoolExecutor"]).ThreadPoolExecutor(max_workers=8) as ex:
        futs = {ex.submit(analyze_ticker, t, spy, rs_map): t for t in FALLBACK_TICKERS[:150]}
        for f in __import__("concurrent.futures", fromlist=["as_completed"]).as_completed(futs):
            r = f.result()
            if r and r["score"] > 40:
                results.append(r)

    results.sort(key=lambda x: x.get(period_field, 0), reverse=True)
    return {
        "period":  period,
        "field":   period_field,
        "results": results[:20],
    }
