"""
main.py — Velox backend entry point
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import logging

from app.routers.routes import router

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)s  %(name)s — %(message)s",
)

app = FastAPI(
    title="Velox Engine",
    description="Real-time swing screener backend for Velox",
    version="1.0.0",
)

# Allow Vercel frontend + local dev
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://localhost:3000",
        "https://velox.vercel.app",
        "https://*.vercel.app",
        "*",   # open during dev — tighten for production
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(router, prefix="/api")


@app.get("/")
def root():
    return {
        "service": "Velox Engine",
        "version": "1.0.0",
        "docs":    "/docs",
        "health":  "/api/health",
    }
